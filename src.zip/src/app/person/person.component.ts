import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  firstName:string='shun';
  lastName:string='mathi';
  gender:string='F';
  age:number=22;
  columnSpan=2;
  showDetails:boolean=false;
  toggleDetails():void{
    this.showDetails=!this.showDetails;
  }
  
  
  }

