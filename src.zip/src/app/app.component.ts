import { Component,Output } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl:'./app.component.html'
 
})
export class AppComponent {
 
 userText:string='shun';
}
