import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PersonComponent } from './person/person.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeTitlePipe } from './employee-list/employeeTitle.pipes';
import { EmployeeCountComponent } from './employee-list/employee-count/employee-count.component';
import {SimpleComponent} from './others/others';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent} from './others/pageNotFound.component'

@NgModule({
  declarations: [
    AppComponent,
    PersonComponent,
    EmployeeListComponent,
    EmployeeTitlePipe,
    EmployeeCountComponent,
    SimpleComponent,
    HomeComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
