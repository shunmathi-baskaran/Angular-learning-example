import { Component, OnInit } from '@angular/core';
import { IEmployee } from './IEmployee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  providers:[EmployeeService]
})
export class EmployeeListComponent implements OnInit {
  employees:IEmployee[];
 /*private  _employeeService:EmployeeService;
   constructor( _employeeService:EmployeeService){
     this._employeeService=_employeeService;
   }*/
  constructor(private _employeeService:EmployeeService) {}

  ngOnInit() {
    this.employees=this._employeeService.getEmployeeDetails();
  }
  
  selectedEmployeeCountRadioButton:string="all";

    getTotalEmployees():number{
      return this.employees.length;
    }
    getTotalMaleEmployees():number{
      return this.employees.filter(e=>e.gender==='male').length;
    }
    getTotalFemaleEmployees():number{
      return this.employees.filter(e=>e.gender==='female').length;
    }
    onEmployeeCountRadioButtonChange(selectedRadioButtonValue:string):void{
     this.selectedEmployeeCountRadioButton=selectedRadioButtonValue;
    }
  }


