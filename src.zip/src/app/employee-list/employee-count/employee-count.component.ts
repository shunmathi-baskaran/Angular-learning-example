import { Input,Output,Component, OnInit,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  selectedRadioButtonValue:string='all';

  @Output()
  countRadioButtonSelectionChange:EventEmitter<string>=new EventEmitter<string>();

  @Input()
  all:number;

  @Input()
  male:number;

  @Input()
  female:number;

  onCountRadioButtonSelectionChange(){
    this.countRadioButtonSelectionChange.emit(this.selectedRadioButtonValue);
    console.log(this.selectedRadioButtonValue);
  }
}
