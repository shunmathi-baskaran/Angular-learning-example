import {Injectable} from '@angular/core'
import {IEmployee} from './IEmployee'
@Injectable()
export class EmployeeService {

getEmployeeDetails():IEmployee[]{
    return[
          {code:'emp10001',name:'Shrinivas',gender:'male',salary:25000,dob:'08/17/1996'},
        {code:'emp10002',name:'Shunmathi',gender:'female',salary:20000,dob:'12/03/1996'},
        {code:'emp10003',name:'Ravali',gender:'female',salary:25000,dob:'07/22/1997'},
        {code:'emp10004',name:'Vaishnavi',gender:'female',salary:20000,dob:'04/13/1997'},
        {code:'emp10005',name:'Subasri',gender:'female',salary:20000,dob:'09/13/1996'},
        {code:'emp10006',name:'Praveen',gender:'male',salary:20000,dob:'09/20/1996'}
];
    

}
}