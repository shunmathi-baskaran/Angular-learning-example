export interface IEmployee{
    code:string;
    name:string;
    gender:string;
    salary:number;
    dob:string;
}